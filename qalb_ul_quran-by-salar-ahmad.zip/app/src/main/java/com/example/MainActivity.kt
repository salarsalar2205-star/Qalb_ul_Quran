package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTimeFilled
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.AccessTime
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.AppTab
import com.example.ui.components.CityPickerBottomSheet
import com.example.ui.components.NoorTopBar
import com.example.ui.components.SettingsBottomSheet
import com.example.ui.screens.PrayerScreen
import com.example.ui.screens.ProfileTabRoot
import com.example.ui.screens.QiblaScreen
import com.example.ui.screens.QuranScreen
import com.example.ui.screens.TasbeehScreen
import com.example.ui.theme.NoorTheme
import com.example.viewmodel.NoorViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: NoorViewModel = viewModel()
            NoorAppRoot(viewModel = viewModel)
        }
    }
}

@Composable
fun NoorAppRoot(viewModel: NoorViewModel) {
    val prefs by viewModel.preferences.collectAsStateWithLifecycle()
    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
    val prayerSchedule by viewModel.prayerSchedule.collectAsStateWithLifecycle()
    val countdownText by viewModel.countdownText.collectAsStateWithLifecycle()
    val filteredSurahs by viewModel.filteredSurahs.collectAsStateWithLifecycle()
    val surahSearchQuery by viewModel.surahSearchQuery.collectAsStateWithLifecycle()
    val surahFilter by viewModel.surahFilter.collectAsStateWithLifecycle()
    val selectedSurahState by viewModel.selectedSurahState.collectAsStateWithLifecycle()
    val audioState by viewModel.audioState.collectAsStateWithLifecycle()
    val isDetectingLocation by viewModel.isDetectingLocation.collectAsStateWithLifecycle()
    val locationFeedback by viewModel.locationFeedback.collectAsStateWithLifecycle()

    var showCitySheet by remember { mutableStateOf(false) }
    var showSettingsSheet by remember { mutableStateOf(false) }

    NoorTheme(themeMode = prefs.themeMode) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useNavigationRail = maxWidth >= 600.dp

            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                bottomBar = {
                    if (!useNavigationRail) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 2.dp,
                            windowInsets = WindowInsets.navigationBars
                        ) {
                            AppTab.entries.forEach { tab ->
                                val selected = activeTab == tab
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { viewModel.selectTab(tab) },
                                    icon = {
                                        Icon(
                                            imageVector = tabIcon(tab, selected),
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = { Text(tab.label) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                    ),
                                    modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useNavigationRail) {
                        NavigationRail(
                            containerColor = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.fillMaxHeight()
                        ) {
                            AppTab.entries.forEach { tab ->
                                val selected = activeTab == tab
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { viewModel.selectTab(tab) },
                                    icon = {
                                        Icon(
                                            imageVector = tabIcon(tab, selected),
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = { Text(tab.label) },
                                    modifier = Modifier.testTag("nav_rail_${tab.name.lowercase()}")
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .widthIn(max = 760.dp)
                        ) {
                            NoorTopBar(
                                city = prefs.city,
                                themeMode = prefs.themeMode,
                                onOpenLocationPicker = { showCitySheet = true },
                                onToggleTheme = { viewModel.cycleLightDarkTheme() },
                                onOpenSettings = { showSettingsSheet = true }
                            )

                            Box(modifier = Modifier.weight(1f)) {
                                when (activeTab) {
                                    AppTab.PRAYER -> PrayerScreen(
                                        schedule = prayerSchedule,
                                        countdownText = countdownText,
                                        prefs = prefs,
                                        onOpenQibla = { viewModel.selectTab(AppTab.QIBLA) },
                                        onOpenQuran = { viewModel.selectTab(AppTab.QURAN) },
                                        onOpenLocationPicker = { showCitySheet = true },
                                        onOpenSettings = { showSettingsSheet = true }
                                    )

                                    AppTab.QURAN -> QuranScreen(
                                        surahs = filteredSurahs,
                                        searchQuery = surahSearchQuery,
                                        activeFilter = surahFilter,
                                        detailState = selectedSurahState,
                                        audioState = audioState,
                                        prefs = prefs,
                                        onSearchChange = viewModel::updateSurahSearch,
                                        onFilterChange = viewModel::updateSurahFilter,
                                        onOpenSurah = viewModel::openSurah,
                                        onCloseSurah = viewModel::closeSurahDetail,
                                        onPlaySurah = viewModel::playFullSurah,
                                        onPlayAyah = viewModel::playAyah,
                                        onTogglePlayPause = viewModel::toggleAudioPlayPause,
                                        onSkipAyah = viewModel::skipAyah,
                                        onStopAudio = viewModel::stopAudio,
                                        onToggleBookmark = viewModel::toggleBookmark,
                                        onToggleTranslation = viewModel::setShowTranslation,
                                        onOpenSettings = { showSettingsSheet = true }
                                    )

                                    AppTab.QIBLA -> QiblaScreen(
                                        prefs = prefs,
                                        onOpenLocationPicker = { showCitySheet = true }
                                    )

                                    AppTab.TASBEEH -> TasbeehScreen(
                                        prefs = prefs,
                                        presets = viewModel.allDhikrPresets(),
                                        activePreset = viewModel.activeDhikrPreset(),
                                        onTapTasbeeh = viewModel::incrementTasbeeh,
                                        onResetCount = viewModel::resetCurrentTasbeeh,
                                        onSelectPreset = viewModel::selectDhikrPreset,
                                        onAddCustomDhikr = viewModel::addCustomDhikr
                                    )

                                    AppTab.PROFILE -> ProfileTabRoot(
                                        localPrefs = prefs
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (showCitySheet) {
                CityPickerBottomSheet(
                    currentCity = prefs.city,
                    isDetectingLocation = isDetectingLocation,
                    locationFeedback = locationFeedback,
                    onSelectCity = viewModel::selectCity,
                    onRequestGpsDetection = viewModel::detectGpsLocation,
                    onDismiss = {
                        viewModel.clearLocationFeedback()
                        showCitySheet = false
                    }
                )
            }

            if (showSettingsSheet) {
                SettingsBottomSheet(
                    prefs = prefs,
                    onSetThemeMode = viewModel::setThemeMode,
                    onSetCalculationMethod = viewModel::setCalculationMethod,
                    onSetAsrMadhab = viewModel::setAsrMadhab,
                    onSetReciter = viewModel::setReciter,
                    onSetArabicFontSize = viewModel::setArabicFontSize,
                    onSetShowTranslation = viewModel::setShowTranslation,
                    onSetHaptics = viewModel::setHapticsEnabled,
                    onSetDistanceMiles = viewModel::setDistanceInMiles,
                    onDismiss = { showSettingsSheet = false }
                )
            }
        }
    }
}

private fun tabIcon(tab: AppTab, selected: Boolean): ImageVector = when (tab) {
    AppTab.PRAYER -> if (selected) Icons.Filled.AccessTimeFilled else Icons.Outlined.AccessTime
    AppTab.QURAN -> if (selected) Icons.Filled.MenuBook else Icons.Outlined.MenuBook
    AppTab.QIBLA -> if (selected) Icons.Filled.Explore else Icons.Outlined.Explore
    AppTab.TASBEEH -> if (selected) Icons.Filled.AutoAwesome else Icons.Outlined.AutoAwesome
    AppTab.PROFILE -> if (selected) Icons.Filled.Person else Icons.Outlined.Person
}
